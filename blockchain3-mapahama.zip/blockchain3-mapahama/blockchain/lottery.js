
export const contractAddr = "0x29f6315A2ea12C31ED9a339d72c40A784b3EA824";  // new contract CommitRevealV2
export const lotteryAbi = [                                                // new ABI for CommitRevealV2
		{
			"inputs": [
				{
					"internalType": "bytes32",
					"name": "hashedNumberSalt",
					"type": "bytes32"
				}
			],
			"name": "commitHashedNumberPayFee",
			"outputs": [],
			"stateMutability": "payable",
			"type": "function"
		},
		{
			"inputs": [
				{
					"internalType": "uint256",
					"name": "_entryFee",
					"type": "uint256"
				}
			],
			"stateMutability": "nonpayable",
			"type": "constructor"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "uint256",
					"name": "timeCounter",
					"type": "uint256"
				}
			],
			"name": "commitRevealTime",
			"type": "event"
		},
		{
			"inputs": [],
			"name": "endGame",
			"outputs": [],
			"stateMutability": "payable",
			"type": "function"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "string",
					"name": "moneyBackMessage",
					"type": "string"
				}
			],
			"name": "lessThanThreePlayers",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "string",
					"name": "message",
					"type": "string"
				}
			],
			"name": "log",
			"type": "event"
		},
		{
			"inputs": [
				{
					"internalType": "uint256",
					"name": "guessNumber",
					"type": "uint256"
				},
				{
					"internalType": "uint256",
					"name": "saltNumber",
					"type": "uint256"
				}
			],
			"name": "revealGuessNumberAndSalt",
			"outputs": [],
			"stateMutability": "nonpayable",
			"type": "function"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "uint256",
					"name": "arrPlayersRevealedLength",
					"type": "uint256"
				}
			],
			"name": "showArrPlayersRevealedCorrectlylength",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "uint256",
					"name": "arrWinLength",
					"type": "uint256"
				}
			],
			"name": "showArrWinnersLength",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "bytes32",
					"name": "committedHash",
					"type": "bytes32"
				}
			],
			"name": "showCommittedHash",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "uint256",
					"name": "balance",
					"type": "uint256"
				}
			],
			"name": "showContractBalance",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "uint256",
					"name": "_counterPlayersCommittedNotRevealed",
					"type": "uint256"
				}
			],
			"name": "showCounterPlayersCommittedNotRevealed",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "uint256",
					"name": "lastWinNumber",
					"type": "uint256"
				}
			],
			"name": "showLastWinNumber",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "address",
					"name": "lastWinner",
					"type": "address"
				}
			],
			"name": "showLastWinner",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "uint256",
					"name": "randNum",
					"type": "uint256"
				}
			],
			"name": "showRandomNumber",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": true,
					"internalType": "address",
					"name": "winnerAddress",
					"type": "address"
				}
			],
			"name": "showWinnerAddress",
			"type": "event"
		},
		{
			"inputs": [
				{
					"internalType": "uint256",
					"name": "_commitRevealPeriod",
					"type": "uint256"
				}
			],
			"name": "startCommitPeriod",
			"outputs": [],
			"stateMutability": "nonpayable",
			"type": "function"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "uint256",
					"name": "sumAllNumbers",
					"type": "uint256"
				}
			],
			"name": "sumFromAllNumberss",
			"type": "event"
		},
		{
			"inputs": [],
			"name": "countPlayersCommittedNotRevealed",
			"outputs": [
				{
					"internalType": "uint256",
					"name": "",
					"type": "uint256"
				}
			],
			"stateMutability": "view",
			"type": "function"
		},
		{
			"inputs": [],
			"name": "entryFee",
			"outputs": [
				{
					"internalType": "uint256",
					"name": "",
					"type": "uint256"
				}
			],
			"stateMutability": "view",
			"type": "function"
		},
		{
			"inputs": [],
			"name": "lastWinner",
			"outputs": [
				{
					"internalType": "address",
					"name": "",
					"type": "address"
				}
			],
			"stateMutability": "view",
			"type": "function"
		},
		{
			"inputs": [],
			"name": "ownerAddress",
			"outputs": [
				{
					"internalType": "address payable",
					"name": "",
					"type": "address"
				}
			],
			"stateMutability": "view",
			"type": "function"
		},
		{
			"inputs": [],
			"name": "winningNumber",
			"outputs": [
				{
					"internalType": "uint256",
					"name": "",
					"type": "uint256"
				}
			],
			"stateMutability": "view",
			"type": "function"
		}
	];
