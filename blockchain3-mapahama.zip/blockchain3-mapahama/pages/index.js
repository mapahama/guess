// 1 show winning Number   -  DONE
// 2 show countPlayersEnteredGame   - DONE           
// 3 show event showWinnerAddress - DONE 
// 4 check deployment on infura - DONE
// commited guess-number MUST be less than 1000 !  DONE
//
// TODO: set success message 
// TODO: in smart contract state update should be made before transfering ether. Otherwise Re-entrancy attack from hackers is possible
// TODO: notify the players if they won the game or lost the game (in the JS endGame logic or smart contract endGame logic via event)
// TODO: implement timer for commit and reveal 
// TODO: implement Chainlink VRF for random number generator in the smart contract
// Docs START //
// https://bulma.io/documentation/components/

// Docs END //
import styles from "../styles/Home.module.css"; // TODO all styles in a separate css folder
import Head from "next/head";
import Web3 from "web3";
import { contractAddr, lotteryAbi } from "@/blockchain/lottery";
import { useState, useEffect } from "react";
import 'bulma/css/bulma.min.css';
import variables from "../styles/variables.module.scss";


export default function Home() {
  const [web3, setWeb3] = useState();
  const [senderAddress, setSenderAddress] = useState(''); // !important set is as empty String by default
  const [shortenedSenderAddress, setShortenedSenderAddress] = useState(''); // used only 1 in page header (hello)
  const [lcContract, setLcContract] = useState();
  const [lotteryPot, setLotteryPot] = useState(0); // !important  set it 0 by default
  const [commitPeriod, setCommitPeriod] = useState(''); 
  const [errorMessage, setErrorMessage] = useState('');  
  const [commitNumber, setCommitNumber] = useState('');
  const [commitSalt, setCommitSalt] = useState('salt is not generated yet'); 
  const [revealNumber, setRevealNumber] = useState('');
  const [revealSalt, setRevealSalt] = useState('');
  const [evtMessage, setEvtMessage] = useState(''); // event msg
  const [ownerAddress, setOwnerAddress] = useState(''); // !important set is as empty String by default
  const [lastWinner, setLastWinner] = useState('No winner determined yet');
  const [lastWinNumber, setLastWinNumber] = useState('No winning number yet'); 
  const [countPlayers, setCountPlayers] = useState(0); 
  const [randomNumSmartContract, setRandomNumSmartContract] = useState(''); 
  const [commitRevealTime, setCommitRevealTime] = useState(''); // !important set is as empty String by default


    // web3 is input parameter here
    const lotteryContract = web3 => {
      return new web3.eth.Contract(
        lotteryAbi,
        contractAddr
      )
    };
  ////////////////////////START show components AND connect to MetaMask AND connect to Smart Contract - on initial page load only /////
  /*
  * -->useEffect<-- hook with an empty dependency array in a React component
  * ensures that the function is only triggered once when the component is initially rendered
  * So it will be triggered only on -->page load<--
  */
  // Tested - works on page load!
  const onPageLoad = async () => {

    if (typeof window !== "undefined" && typeof window.ethereum !== "undefined") {
      console.log("MetaMask is installed.");
      try {
        const accounts = await window.ethereum.request({ method: "eth_requestAccounts"});
      
        console.log("Accounts found:", accounts);
        const web3 = new Web3(window.ethereum);
        setWeb3(web3);
        setSenderAddress(accounts[0]);

        // used only 1 to show message sender in the page header
        var shortenedSenderAddress = shortenHash(accounts[0]);
        setShortenedSenderAddress(shortenedSenderAddress);

        const lc = lotteryContract(web3);
        setLcContract(lc);
        
      } catch(err) {
        console.error("Error connecting to MetaMask: ", err);
      }
    } else {
      console.log("MetaMask is not installed.");
    }
  };

////////////////////////END show components AND connect to MetaMask AND connect to Smart Contract - on initial page load only /////


/////////////////////////START show smart contract balance ///////////////////////////////
  const getPot = async () => {
    try {
      const pot = await web3.eth.getBalance(contractAddr).then(function(balanceInWei) { // hardcoded contract address
        var balanceInEther = web3.utils.fromWei(balanceInWei, 'ether');
        console.log(balanceInEther);
        
        setLotteryPot(balanceInEther + " ETH");
    });
    } catch(err) {
      console.error("Error fetching Smart Contract balance ", err);
    }
  }
/////////////////////////END show smart contract balance ///////////////////////////////


/////////////////////////START show last winner before game begin ///////////////////////////////
  const getLastWinner = async () => {
    try {
      const _lastWinner = await lcContract.methods.lastWinner().call();
      console.log("last winner: ", _lastWinner);
      var shortenedHashLastWinner = shortenHash(_lastWinner);
      setLastWinner(shortenedHashLastWinner);

    } catch(err) {
      console.error("Error fetching last winner from smart contract ", err);
    }
  }
/////////////////////////START show last winner before game begin ///////////////////////////////


/////////////////////////START show current number of players entered the game ///////////////////////////////
  const getCountPlayers = async () => {
    try {
      const _counterPlayers = await lcContract.methods.countPlayersCommittedNotRevealed().call();
      console.log("players in game: ", _counterPlayers.toString());
      setCountPlayers(_counterPlayers.toString());

    } catch(err) {
      console.error("Error fetching counter for players entered the game ", err);
    }
  }
/////////////////////////END show current number of players entered the game ///////////////////////////////

/////////////////////////START show last winning number before game begin ///////////////////////////////
  const getLastWinNum = async () => {
    try {
      const _lastWinNum = await lcContract.methods.winningNumber().call();
      setLastWinNumber(_lastWinNum.toString());
      console.log("last winning number: ", _lastWinNum);
      
    } catch(err) {
      console.error("Error fetching last winning number from smart contract", err);
    }
  }
/////////////////////////START show last winner before game begin ///////////////////////////////

////////////////////////START get contract owner address ///////////////////////////////
  const getOwnerAddress = async () => {
    try {
      const ownerAddr = await lcContract.methods.ownerAddress().call();
      console.log("Contract owner address:", ownerAddr);
      setOwnerAddress(ownerAddr);

    } catch(err) {
      console.error("Error fetching Smart Contract owner address ", err);
    }
  }
/////////////////////////END get contract owner address ///////////////////////////////


///////////////////////////START button click - connect wallet /////////////////////////////////
 // Function to handle the connection logic
 const connectWalletHandler = async () => {
  if (typeof window !== "undefined" && typeof window.ethereum !== "undefined") { // check is MetaMask is installed
    try {
      const web3 = new Web3(window.ethereum);
      // Request account access
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      setSenderAddress(accounts[0]); // Set the first account as the connected account

      // used only 1 to show message sender in the page header
      var shortenedSenderAddress = shortenHash(accounts[0]);
      setShortenedSenderAddress(shortenedSenderAddress);

      alert('MetaMask is connected');
    } catch (error) {
      console.error("Error connecting to MetaMask ", error);
      alert('Failed to connect MetaMask, please try again!');
    }
  } else {
    alert('Please install MetaMask!');
  }
};
///////////////////////////END button click - connect wallet /////////////////////////////////




  // hook to show information from Smart Contract on the User Interface
  // the informations will be updated with another hook, handling events from Smart Contract
useEffect(() => {
  if (!lcContract || !web3) return;
    getPot();
    getOwnerAddress();
    getLastWinner();
    getLastWinNum();
    getCountPlayers();  

  //}, [lcContract, lotteryPot]); // React re-runs the useEffect function, when element from the dependency array changes
}, [lcContract, web3, senderAddress]);


// useEffect to run once on component mount
useEffect(() => {
  onPageLoad();
}, []); // Empty dependency array means this effect runs only once after the initial render on --> page load <--



// metamask accounts changed
/*
 * Within this useEffect, you are attaching an event listener 
 * (window.ethereum.on('accountsChanged', handleAccountsChanged)) 
 * to the window.ethereum object. This listener is set up to call 
 * handleAccountsChanged every time the accountsChanged event is fired by MetaMask.
 */
// Tested - Works on  MetaMask account change!
useEffect(() => {
  const handleAccountsChanged = (accounts) => {
    console.log("Accounts changed:", accounts);
    setSenderAddress(accounts[0]); // automatically use the changed account

    // used only 1 to show message sender in the page header
    var shortenedSenderAddress = shortenHash(accounts[0]);
    setShortenedSenderAddress(shortenedSenderAddress);
  };

  if (window.ethereum) {
    window.ethereum.on('accountsChanged', handleAccountsChanged);
  }
  // React calls this part of the code "return" when the component is no longer used
  // so delete listener, when not needed anymore
  return () => {
    if (window.ethereum) {
      //window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
    }
  };
}, []); // Empty dependency array means this effect runs only once on mount


// subscribe for all events coming from Smart Contract
// update info on the User Interface according to the info from received events 
// works
useEffect(() => {
  if (!lcContract) return;

  getEventLessThanThreePlayers();
  getEventShowContractBalance();
  getEventShowCounterPlayersCommittedNotRevealed();
  getEventShowLastWinner();
  getEventShowLastWinNumber();
  getEventShowRandomNumber();
  getCommitRevealTime(); // used for time counter
  // Clean up the subscription
  return () => {
   // can not manage to unsubscribe.......
  };
}, [lcContract]); // Effect dependencies



// subsciption for smart contract event lessThanThreePlayers
const getEventLessThanThreePlayers = async () => {

  setEvtMessage('');
  if (!lcContract) return;

  try {
    lcContract.events.lessThanThreePlayers({
      filter: {},
      fromBlock: 'latest'
    }).on('data', (event) => {
      var message = event.returnValues[0];
      console.log(message);
      setEvtMessage(message); // Set the message received from the event
    }).on('error', (error) => {
      console.error("Error in event listener lessThanThreePlayers: ", error);
      //throw error; 
    });
  } catch (error) {
    console.error("Failed to subscribe to event lessThanThreePlayers: ", error);
  }
}

// subsciption for smart contract event showContractBalance (on update)
const getCommitRevealTime = async () => {

  if (!lcContract) return;

  try {
    lcContract.events.commitRevealTime({
      filter: {},
      fromBlock: 'latest'
    }).on('data', (event) => {
      var _commitRevealTime = event.returnValues[0];
      console.log("Commit Reveal Time: ", _commitRevealTime.toString());
      setCommitRevealTime(_commitRevealTime.toString()); // Set in state variables
    }).on('error', (error) => {
      console.error("Error in event listener commitRevealTime: ", error);
      //throw error; 
    });
  } catch (error) {
    console.error("Failed to subscribe to event commitRevealTime: ", error);
  }
}



// subsciption for smart contract event showContractBalance (on update)
const getEventShowContractBalance = async () => {

  if (!lcContract) return;

  try {
    lcContract.events.showContractBalance({
      filter: {},
      fromBlock: 'latest'
    }).on('data', (event) => {
      var balanceInWei = event.returnValues[0];
      var balanceInEther = web3.utils.fromWei(balanceInWei, 'ether');
      console.log("Pot in wei: ", balanceInWei);
      console.log("Pot in ether: ", balanceInEther);
      setLotteryPot(balanceInEther + " ETH"); // Set in state variables
    }).on('error', (error) => {
      console.error("Error in event listener showContractBalance: ", error);
      //throw error; 
    });
  } catch (error) {
    console.error("Failed to subscribe to event showContractBalance: ", error);
  }
}



// subscription for counter players entered the game
const getEventShowCounterPlayersCommittedNotRevealed = async () => {

  if (!lcContract) return;

  try {
    lcContract.events.showCounterPlayersCommittedNotRevealed({
      filter: {},
      fromBlock: 'latest'
    }).on('data', (event) => {
      var counter = event.returnValues[0];
      console.log("Current numbers of players: ", counter.toString());
      setCountPlayers(counter.toString()); // Set in state variables
    }).on('error', (error) => {
      console.error("Error in event listener showCounterPlayersCommittedNotRevealed: ", error);
      //throw error; 
    });
  } catch (error) {
    console.error("Failed to subscribe to event showCounterPlayersCommittedNotRevealed: ", error);
  }
}


// subsciption for last Winner-Address  (on update)
const getEventShowLastWinner = async () => {

  if (!lcContract) return;

  try {
    lcContract.events.showLastWinner({
      filter: {},
      fromBlock: 'latest'
    }).on('data', (event) => {
      var _lastWinner = event.returnValues[0];
      console.log("Last winner: ", _lastWinner);
      setLastWinner(_lastWinner); // Set in state variables
    }).on('error', (error) => {
      console.error("Error in event listener showLastWinner: ", error);
      //throw error; 
    });
  } catch (error) {
    console.error("Failed to subscribe to event showLastWinner: ", error);
  }
}

// subsciption for last Winning Number  (on update)
const getEventShowLastWinNumber = async () => {

  if (!lcContract) return;

  try {
    lcContract.events.showLastWinNumber({
      filter: {},
      fromBlock: 'latest'
    }).on('data', (event) => {
      var _lastWinNum = event.returnValues[0];
      console.log("Last winning number: ", _lastWinNum);
      setLastWinNumber(_lastWinNum.toString()); // Set in state variables
    }).on('error', (error) => {
      console.error("Error in event listener showLastWinNumber: ", error);
      //throw error; 
    });
  } catch (error) {
    console.error("Failed to subscribe to event showLastWinNumber: ", error);
  }
}

// subsciption for generated random number from smart contract (when more than 1 players guessed the winning number)
// works
const getEventShowRandomNumber = async () => {

  setRandomNumSmartContract('');  // clean previous input
  if (!lcContract) return;

  try {
    lcContract.events.showRandomNumber({
      filter: {},
      fromBlock: 'latest'
    }).on('data', (event) => {
      var randNum = event.returnValues[0];
      console.log("Random number generated by Smart Contract: ", randNum.toString());
      setRandomNumSmartContract(randNum.toString()); // set in state variables
    }).on('error', (error) => {
      console.error("Error in event showRandomNumber: ", error);
      //throw error; 
    });
  } catch (error) {
    console.error("Failed to subscribe to event showRandomNumber: ", error);
  }
}

// helper function
// Function to increase gas by 30% (to make sure transactions dont get rejected)
function increaseGasBy30Percent(estimatedGas) {
  const increaseFactor = BigInt(130); // Increase by 30% as a BigInt
  const increasedGas = estimatedGas * increaseFactor / BigInt(100); // Perform calculation using BigInt
  return increasedGas;
}

// helper function
// shorten the hashes, shown on the frontend (logged in user, last winner)
function shortenHash(hash) {
  // Ensure the hash is a string and long enough to shorten
  if (typeof hash === 'string' && hash.length > 8) {
    return hash.slice(0, 6) + '...' + hash.slice(-4);
  }
  return hash; // Return the original hash if it's too short to shorten
}

///////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

//////////////////////////////////START start commit phase /////////////////////////////
 // Step 1: Define Commitment Time
 // on button click call function "startCommitPhase" from Smart Contract
 const startCommitPeriod = async () => {
  setErrorMessage(''); // Clear previous error messages
 
    try {
       // Convert commitPeriod to an integer
       // check in entered value is a number
        const period = parseInt(commitPeriod, 10);
        if (isNaN(period)) {
           setErrorMessage('err! At step 1: Invalid commit period.');
            return;
        }

       // Estimate gas for the transaction
       const estimatedGas = await lcContract.methods.startCommitPeriod(period).estimateGas({ from: senderAddress });
       console.log('Estimated Gas:', estimatedGas);
       // increase gas 
       const increasedGas = increaseGasBy30Percent(estimatedGas);
       console.log('Increased Gas:', increasedGas);

        // Sending the transaction to the blockchain
        const res = await lcContract.methods.startCommitPeriod(period).send({ from: senderAddress, gas: increasedGas });
        console.log('Transaction response:', res);

   } catch (err) {
       let errMsg = err.message;

        // Extracting the smart contract "require" message after '->'
        if (errMsg.includes("->")) {
            errMsg = errMsg.split('->')[1].trim();
       }
       console.log(errMsg);
       setErrorMessage("err! At step 1: " + errMsg);
    } 

};
//////////////////////////////////END start commit phase /////////////////////////////


/////////////////// START commit number and salt //////////////////////
const handleCommit = async () => {
  setErrorMessage(""); // Clear previous messages

  // make sure commmitted guess number is > 0  and <= 1000 AND salt is generated
  if (commitNumber < 1 || commitNumber > 1000 || !commitNumber) {
    setErrorMessage("err! At step 2: Number must be between 1 and 1000"); 
  } else if (commitSalt === 'salt is not generated yet') {
    setErrorMessage("err! At step 2: Please generate salt number"); 
  } else {
    const hashedNumSalt = hashNumberSalt(commitNumber, commitSalt);
    console.log("commit hash: ", hashedNumSalt);
    console.log("commit salt: ", commitSalt);
  
    const valueToSend = web3.utils.toWei('0.01', 'ether'); // The value to send with the transaction
  
    try {
      const estimatedGas = await lcContract.methods.commitHashedNumberPayFee(hashedNumSalt).estimateGas({ from: senderAddress, value: valueToSend });
      console.log("Estimated Gas:", estimatedGas);
       // increase gas 
       const increasedGas = increaseGasBy30Percent(estimatedGas);
       console.log('Increased Gas:', increasedGas);
  
      const result = await lcContract.methods.commitHashedNumberPayFee(hashedNumSalt).send({
        from: senderAddress,
        value: valueToSend,
        gas: increasedGas
      });
    } catch (err) {
      let errMsg = err.message;
      if (errMsg.includes("->")) {
        errMsg = errMsg.split('->')[1].trim();
      } 
      console.log(errMsg);
      // if err msg (from MetaMask for example) is longer than 100 characters, show only 100 characters
      const shortenedErrMessage = errMsg.length > 100 ? `${errMsg.substring(0, 100)}...` : `${errMsg}`;
      setErrorMessage("err! At step 2: " + shortenedErrMessage);
    }
  }
};

// works
const generateRandomSalt = () => { // replace with some random hexadecimal hash
  const min = 10000;
  const max = 99999;
  const salt = Math.floor(Math.random() * (max - min + 1)) + min;
  setCommitSalt(salt);
};
// works
const hashNumberSalt = (number, salt) => {
  const numsToConcatenatedStr = `${number}${salt}`;
  const hash = web3.utils.keccak256Wrapper(numsToConcatenatedStr);
  return hash;
};
////////////////////END commit number and salt////////////////////////




  //////////////////// START REVEAL  /////////////////////////////////
  const handleReveal = async () => {
    setErrorMessage(""); // Clear previous messages

    // Console logs
    console.log("Number", revealNumber)
    console.log("Salt", revealSalt)

    // make sure time is set
    if (revealNumber == '' || revealNumber === undefined || revealSalt == '' || revealSalt === undefined) {
      setErrorMessage("err! At step 4: Please set the values for Reveal Numer and Reveal Salt")
      return;
    }

    // web3js
    try {
      const estimatedGas = await lcContract.methods.revealGuessNumberAndSalt(revealNumber, revealSalt).estimateGas({
        from: senderAddress,
      });
      console.log("REVEAL::Estimated Gas:", estimatedGas);
      // increase gas 
      const increasedGas = increaseGasBy30Percent(estimatedGas);
      console.log('Increased Gas:', increasedGas);

      const result = await lcContract.methods.revealGuessNumberAndSalt(revealNumber, revealSalt).send({
        from: senderAddress,
        gas: increasedGas
      });
    } catch (err) {
      let errMsg = err.message;
      if (errMsg.includes("->")) {
        errMsg = errMsg.split('->')[1].trim();
      }
      console.log(errMsg);
      // if err msg (from MetaMask for example) is longer than 100 characters, show only 100 characters
      const shortenedErrMessage = errMsg.length > 100 ? `${errMsg.substring(0, 100)}...` : `${errMsg}`;
      setErrorMessage("err! At step 4: " + shortenedErrMessage);
    }
  };
  //////////////////// END REVEAL  /////////////////////////////////

  //////////////////// START CLOSE GAME  /////////////////////////////////
  const handleCloseGame = async () => {
    setErrorMessage(""); // Clear previous messages

    try {
      const estimatedGas = await lcContract.methods.endGame().estimateGas({
        from: senderAddress,
      });
      console.log("END::Estimated Gas:", estimatedGas);
      // increase gas 
      const increasedGas = increaseGasBy30Percent(estimatedGas);
      console.log('Increased Gas:', increasedGas);

      const result = await lcContract.methods.endGame().send({
        from: senderAddress,
        gas: increasedGas
      });
    } catch (err) {
      let errMsg = err.message;
      if (errMsg.includes("->")) {
        errMsg = errMsg.split('->')[1].trim();
      }
      console.log(errMsg);
      const shortenedErrMessage = errMsg.length > 100 ? `${errMsg.substring(0, 100)}...` : `${errMsg}`;
      setErrorMessage("err! At step 5: " + shortenedErrMessage);
    }
  };
  //////////////////// END CLOSE GAME  /////////////////////////////////

return (
  <section className = "section" style = {{background: "white", margin: "0", padding: "0"}}>
    <Head>
      <title>Lottery</title>
      <meta name="description" content="Lottery dApp" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link rel="icon" href="/favicon.ico" />
    </Head>

    <div className={ `${variables.page_header} card`}>
     <div>
       <h1 className={ `${variables.game_title} title has-text-centered` }>
        Lottery dApp
        <img src="/ether.png" className={ `${variables.icon_ether}`} />
      </h1> 
     </div>
     <div className={ `${variables.sender_address} notification` }>
       <strong>Hello<img src="/waving-hand.png"  className={ `${variables.icon_waving_hand} icon`}/> {shortenedSenderAddress}</strong>
     </div>
    </div>

    <section className="section" style={{ background: "#140325", minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', paddingTop: "5em" }}>
      <div className="container">
        <div className="columns is-centered">
          <div className="column" style={{ display: 'flex', justifyContent: 'center', marginBottom: "1em" }}>
            <div className="box " style={{ width: "70%", paddingTop: "0",
            background: "rgb(44,41,91)",
            background: "radial-gradient(circle, rgb(48 19 83 / 96%), rgba(31,0,34,1) 100%)",
            boxShadow: "0px 2px 20px 0px rgb(247 121 255)",
            border: "0.2em solid", borderColor: "#efa0ffa3" }}>
          
              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '2.5em'}}>
                {!senderAddress && <button onClick={connectWalletHandler} className="button is-success" style={{ background: "#4d9cb6", color: "#e4e4e4" }}>Connect Wallet</button>}
              </div>

              {senderAddress.toLowerCase() == ownerAddress.toLowerCase() && ownerAddress && <article className="message is-dark">
                  <div className="box" style={{ backgroundColor: "#bc737324", marginTop: "-2em" }}>
                    <h1 className="title has-text-centered" style={{  color: "rgb(247 206 206 / 41%)" }}>
                      Contract Owner Tools
                    </h1>
                  </div>
              </article>}

              {errorMessage && errorMessage.includes('err!') && (
                <div style={{ marginBottom: '1em' }}>
                  <article className="message is-danger">
                    <div class="message-header">
                      <p>Error</p>
                    </div>
                    <div class="message-body">
                      {errorMessage.replace('err!', '')}
                    </div>
                  </article >
              </div>)}
              <div className={`${styles.menu_container_div}`}>
              {senderAddress.toLowerCase() === ownerAddress.toLowerCase() && ownerAddress && <article className="message is-dark"  style={{ marginTop: '1em' }}>
                <div className={ `${variables.menu_box_header} message-header has-text-grey-light` }>
                  <p>Define Commit & Reveal Time</p>
                </div>
                <div className={ `${variables.menu_box_body} message-body` }  style={{ height: "8em" }}>
                  <input className={ `${variables.menu_box_input_field} input` } type="number"
                         value={commitPeriod} onChange={e => setCommitPeriod(e.target.value)}
                         placeholder="Enter Commit Period"/>
                  <button onClick={startCommitPeriod} className={ `${variables.success_button} button` }>Start Game</button>
                </div>
              </article>}

              {senderAddress.toLowerCase() !== ownerAddress.toLowerCase() && ownerAddress && <article className="message is-dark">
                <div className={ `${variables.menu_box_header} message-header has-text-grey-light` }>
                  <p>Guess Number & Generate Salt</p>
                </div>
                <div className={  `${variables.menu_box_body} message-body` }>
                
                  <input value={commitNumber} onChange={(e) => setCommitNumber(e.target.value)} className={ `${variables.menu_box_input_field} input` } type="number" placeholder="Enter your guess number"/>
                  <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginBottom: "0.5em", width: "80%", gap: "0.4em" }}>
                    <button  onClick={generateRandomSalt} className={ `${variables.success_button} button` }>Generate Salt</button>
                    <input value={commitSalt} onChange={(e) => setCommitSalt(e.target.value)} className="input" id="saltOutput" style={{ pointerEvents: "none", opacity: "88%", background: "rgb(122 104 149 / 49%)" }}/>
                  </div>
                  <button onClick={handleCommit} className={ `${variables.success_button} button` }>Commit Number and Salt</button>
                </div>
              </article>}

              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginBottom: "1em" }}>
                  <img src="/trophy.png" className="icon"/><strong style={{ color: "hsl(37.11deg 100% 50%)", padding: "0, 0.9em" }}> {lotteryPot}</strong>
                  <span id="balance">
                  </span> <img src="/trophy.png"  className="icon"/>
                </div>
                <div style={{ color: "#bd88ff99", fontSize: "1em" }}>
                 Players: <b>{countPlayers}</b>
                </div>
              </div>

              {senderAddress.toLowerCase() !== ownerAddress.toLowerCase() && ownerAddress.toLowerCase() !== '' && <article className="message is-dark">
              <div className={ `${variables.menu_box_header} message-header has-text-grey-light` }>
                    <p>Reveal number</p>
                  </div>
                  <div className={  `${variables.menu_box_body} message-body` }>

                    <input value={revealNumber || ''} onChange={(e) => { setRevealNumber(e.target.value) }} className={ `${variables.menu_box_input_field} input` } type="number" placeholder="Enter your guessed number"/>
                    <input value={revealSalt || ''} onChange={(e) => { setRevealSalt(e.target.value) }} className={ `${variables.menu_box_input_field} input` } type="number" placeholder="Enter your guess salt"/>
                    <button onClick={handleReveal} className={ `${variables.success_button} button` }>Reveal</button>
                  </div>
                </article>}

                {senderAddress.toLowerCase() == ownerAddress.toLowerCase() && ownerAddress.toLowerCase() !== '' && <article className="message is-dark">
                <div className={ `${variables.menu_box_header} message-header has-text-grey-light` }>
                    <p>End Game</p>
                  </div>
                  <div className={  `${variables.menu_box_body} message-body` } style={{ height: "8em", justifyContent: "end" }}>
                    <button onClick={handleCloseGame} className={ `${variables.danger_button} button` }>End Game</button>
                  </div>
                </article>}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: "column", justifyContent: 'center', alignItems: "center", marginTop: "1.3em" }}>
      <div className="notification has-text-grey" style={{ padding: '0.5em 1em', background: "#87c79f1a", width: "14em", marginBottom: "0.7em" }}>
         <strong>Last winner: {lastWinner}</strong><span id="lastWinner"></span>
      </div>
      <div className="notification has-text-grey" style={{ padding: '0.5em 1em', background: "#87c79f1a", width: "14em", marginBottom: "0.7em" }}>
        <strong>Last winning number: {lastWinNumber}</strong><span id="lastWinNum"></span>
      </div>
      <div className="notification has-text-grey" style={{ padding: '0.3em', background: "#1e2d2347", width: "14em", marginBottom: "0.7em", textAlign: "center" }}>
        <a href={`https://sepolia.etherscan.io/address/${contractAddr}`} target = "_blank" style={{ color: "hsl(233deg 89.81% 62.92%)", fontSize: "1.2em" }}>Lottery history</a>
      </div>

      <footer className="footer">
        <div className="content has-text-centered">
          <p>Event Message: {evtMessage}</p>
          {/*
          WORKS WITH CSS <p className={`notification has-text-grey ${styles.martin}`}>Last generated random number: {randomNumSmartContract}</p>
          */}
          <p>Last generated random number: {randomNumSmartContract}</p>
          <p> commit-reveal time for this game (to use in time counter): {commitRevealTime}</p>
        </div>
      </footer>
      </div>
    </section>
  </section>
);
}
